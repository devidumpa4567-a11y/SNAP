package com.snap.clipper

import android.app.Activity
import android.content.Intent
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val pickVideo = 1001
    private var sourceFile: File? = null
    private var transcript: List<SpeechSegment> = emptyList()
    private var highlights: List<Highlight> = emptyList()
    private var selectedHighlight = 0
    private lateinit var status: TextView
    private lateinit var video: VideoView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var exportButton: Button
    private lateinit var transcribeButton: Button
    private lateinit var highlightButton: Button
    private lateinit var modelButton: Button
    private lateinit var highlightList: LinearLayout
    private lateinit var languageSpinner: Spinner

    private val modelFile get() = File(filesDir, "models/ggml-base.bin")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshModelState()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(20))
            setBackgroundColor(Color.rgb(9, 11, 18))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        content.addView(TextView(this).apply {
            text = "SNAP"; textSize = 36f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        content.addView(TextView(this).apply {
            text = "LOCAL AI VIDEO CLIPPER"; textSize = 11f; letterSpacing = .16f
            setTextColor(Color.rgb(167, 139, 250)); setPadding(0, 0, 0, dp(16))
        })
        content.addView(makeButton("＋  Import video") { chooseVideo() }, matchWrap())
        video = VideoView(this).apply { setBackgroundColor(Color.BLACK) }
        content.addView(video, LinearLayout.LayoutParams(-1, dp(205)).apply { topMargin = dp(12) })
        status = TextView(this).apply {
            text = "Import a video. SNAP processes it on this device."
            textSize = 13f; setTextColor(Color.LTGRAY); setPadding(0, dp(12), 0, dp(8))
        }
        content.addView(status)
        content.addView(section("1  OFFLINE SPEECH TRANSCRIPTION"))
        content.addView(TextView(this).apply {
            text = "Download the Whisper base model once (about 142 MB). After that, transcription works offline."
            textSize = 12f; setTextColor(Color.LTGRAY)
        })
        languageSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Hindi", "English", "Auto detect"))
        }
        content.addView(languageSpinner, matchWrap())
        modelButton = makeButton("Download Whisper model") { downloadModel() }
        content.addView(modelButton, matchWrap())
        transcribeButton = makeButton("Transcribe video") { startTranscription() }.apply { isEnabled = false; alpha = .5f }
        content.addView(transcribeButton, matchWrap().apply { topMargin = dp(8) })

        content.addView(section("2  AUTOMATIC HIGHLIGHTS"))
        content.addView(TextView(this).apply {
            text = "Ranks speech windows using Hindi story cues, suspense words, emotional language, questions and narrative changes. Review results before export."
            textSize = 12f; setTextColor(Color.LTGRAY)
        })
        highlightButton = makeButton("Find best moments") { findHighlights() }.apply { isEnabled = false; alpha = .5f }
        content.addView(highlightButton, matchWrap().apply { topMargin = dp(8) })
        highlightList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(highlightList)

        content.addView(section("3  CLIP EXPORT"))
        content.addView(TextView(this).apply { text = "Selected clip start (seconds)"; setTextColor(Color.LTGRAY); textSize = 12f })
        startInput = edit("0"); content.addView(startInput, matchWrap())
        content.addView(TextView(this).apply { text = "End (seconds)"; setTextColor(Color.LTGRAY); textSize = 12f; setPadding(0, dp(8), 0, 0) })
        endInput = edit("30"); content.addView(endInput, matchWrap())
        exportButton = makeButton("Export selected MP4 + SRT captions") { exportClip() }
            .apply { isEnabled = false; alpha = .5f }
        content.addView(exportButton, matchWrap().apply { topMargin = dp(12) })

        content.addView(section("ABOUT OFFLINE SNAP"))
        content.addView(feature("Private processing", "Video, audio and transcript stay on your device."))
        content.addView(feature("No paid API", "Whisper.cpp runs locally. The model download is a one-time setup step."))
        content.addView(feature("Current export", "Exports a trimmed MP4 and a matching SRT caption file. Portrait crop and burned-in animated captions are not yet included in this build."))
        content.addView(TextView(this).apply {
            text = "SNAP 0.2 • On-device prototype"; textSize = 11f; setTextColor(Color.GRAY
            ); gravity = Gravity.CENTER; setPadding(0, dp(22), 0, dp(10))
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "video/*"
        }
        startActivityForResult(intent, pickVideo)
    }

    @Deprecated("Document picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickVideo || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        status.text = "Importing video…"
        thread {
            try {
                val name = queryName(uri)
                val dest = File(filesDir, "source_${System.currentTimeMillis()}_${safeName(name)}")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot open selected video" }
                    FileOutputStream(dest).use { output -> input.copyTo(output) }
                }
                sourceFile = dest
                transcript = emptyList(); highlights = emptyList(); highlightList.removeAllViews()
                runOnUiThread {
                    status.text = "Ready: $name\n${formatBytes(dest.length())} • stored locally"
                    video.setVideoURI(Uri.fromFile(dest))
                    video.setOnPreparedListener { it.isLooping = false; it.start() }
                    transcribeButton.isEnabled = modelFile.exists(); transcribeButton.alpha = if (modelFile.exists()) 1f else .5f
                    exportButton.isEnabled = true; exportButton.alpha = 1f
                    highlightButton.isEnabled = false; highlightButton.alpha = .5f
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Import failed: ${e.message}" }
            }
        }
    }

    private fun queryName(uri: Uri): String {
        var result = "video.mp4"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) result = it.getString(0) ?: result
        }
        return result
    }

    private fun downloadModel() {
        modelButton.isEnabled = false
        status.text = "Downloading Whisper base model (about 142 MB)… Keep SNAP open."
        thread {
            try {
                modelFile.parentFile?.mkdirs()
                val temp = File(modelFile.parentFile, "ggml-base.bin.part")
                val connection = (URL("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin").openConnection() as HttpURLConnection)
                connection.connectTimeout = 20000; connection.readTimeout = 60000
                connection.setRequestProperty("User-Agent", "SNAP-Android")
                connection.connect()
                if (connection.responseCode !in 200..299) error("Model server returned HTTP ${connection.responseCode}")
                val total = connection.contentLengthLong
                connection.inputStream.use { input ->
                    FileOutputStream(temp).use { output ->
                        val buffer = ByteArray(1024 * 256); var count: Int; var done = 0L
                        while (input.read(buffer).also { count = it } >= 0) {
                            if (count == 0) continue
                            output.write(buffer, 0, count); done += count
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                runOnUiThread { status.text = "Downloading Whisper model… $pct%" }
                            }
                        }
                    }
                }
                connection.disconnect()
                require(temp.length() > 100_000_000L) { "Downloaded model is incomplete." }
                if (!temp.renameTo(modelFile)) { temp.copyTo(modelFile, overwrite = true); temp.delete() }
                runOnUiThread {
                    status.text = "Whisper model ready. Transcription can now run offline."
                    modelButton.text = "Whisper model installed"
                    transcribeButton.isEnabled = sourceFile != null; transcribeButton.alpha = if (sourceFile != null) 1f else .5f
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Model download failed: ${e.message}"; modelButton.isEnabled = true }
            }
        }
    }

    private fun refreshModelState() {
        if (modelFile.exists() && modelFile.length() > 100_000_000L) {
            modelButton.text = "Whisper model installed"
            transcribeButton.isEnabled = sourceFile != null; transcribeButton.alpha = if (sourceFile != null) 1f else .5f
        }
    }

    private fun startTranscription() {
        val input = sourceFile ?: return
        if (!modelFile.exists()) { status.text = "Download the Whisper model first."; return }
        transcribeButton.isEnabled = false
        status.text = "Extracting audio and running Whisper locally. Long videos may take several minutes…"
        thread {
            try {
                val pcm = decodeAudioToMono16k(input)
                require(pcm.isNotEmpty()) { "No decodable audio track found." }
                val lang = when (languageSpinner.selectedItemPosition) { 0 -> "hi"; 1 -> "en"; else -> "auto" }
                val raw = WhisperNative.transcribe(pcm, modelFile.absolutePath, lang)
                val parsed = raw.lineSequence().mapNotNull { line ->
                    val parts = line.split('|', limit = 3)
                    if (parts.size != 3) null else {
                        val s = parts[0].toLongOrNull() ?: return@mapNotNull null
                        val e = parts[1].toLongOrNull() ?: return@mapNotNull null
                        SpeechSegment(s / 1000.0, e / 1000.0, parts[2].trim())
                    }
                }.filter { it.text.isNotBlank() }.toList()
                require(parsed.isNotEmpty()) { "Whisper returned no speech. Try another language setting or check the audio." }
                transcript = parsed
                val srt = File(filesDir, "transcript.srt")
                srt.writeText(toSrt(parsed), Charsets.UTF_8)
                runOnUiThread {
                    status.text = "Transcription complete: ${parsed.size} speech segments.\nSaved locally as transcript.srt. Tap Find best moments."
                    highlightButton.isEnabled = true; highlightButton.alpha = 1f
                    transcribeButton.isEnabled = true
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Transcription failed: ${e.message}"; transcribeButton.isEnabled = true }
            }
        }
    }

    // Decode the first audio track with Android MediaCodec, downmix to mono and resample to 16 kHz.
    private fun decodeAudioToMono16k(file: File): FloatArray {
        val extractor = MediaExtractor()
        extractor.setDataSource(file.absolutePath)
        var track = -1
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; break }
        }
        require(track >= 0) { "Video has no audio track." }
        extractor.selectTrack(track)
        val inputFormat = extractor.getTrackFormat(track)
        val mime = inputFormat.getString(MediaFormat.KEY_MIME)!!
        val decoder = MediaCodec.createDecoderByType(mime)
        decoder.configure(inputFormat, null, null, 0); decoder.start()
        val collected = FloatCollector()
        val info = MediaCodec.BufferInfo()
        var inputDone = false; var outputDone = false
        var sampleRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
        var resampleCarry = 0.0
        try {
            while (!outputDone) {
                if (!inputDone) {
                    val inIndex = decoder.dequeueInputBuffer(10000)
                    if (inIndex >= 0) {
                        val buffer = decoder.getInputBuffer(inIndex)!!
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIndex = decoder.dequeueOutputBuffer(info, 10000)
                when {
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = decoder.outputFormat
                        sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = f.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                    outIndex >= 0 -> {
                        val out = decoder.getOutputBuffer(outIndex)
                        if (out != null && info.size > 0) {
                            out.position(info.offset); out.limit(info.offset + info.size)
                            val mono = decodePcmChunk(out.slice(), channels, pcmEncoding)
                            val ratio = sampleRate.toDouble() / 16000.0
                            var pos = resampleCarry
                            while (pos < mono.size) {
                                val idx = pos.toInt().coerceIn(0, mono.lastIndex)
                                val frac = pos - idx
                                val next = min(idx + 1, mono.lastIndex)
                                collected.add((mono[idx] * (1.0 - frac) + mono[next] * frac).toFloat())
                                pos += ratio
                            }
                            resampleCarry = pos - mono.size
                        }
                        outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        decoder.releaseOutputBuffer(outIndex, false)
                    }
                }
            }
        } finally {
            try { decoder.stop() } catch (_: Exception) {}
            decoder.release(); extractor.release()
        }
        return collected.toArray()
    }

    private fun decodePcmChunk(buffer: ByteBuffer, channels: Int, encoding: Int): FloatArray {
        buffer.order(java.nio.ByteOrder.LITTLE_ENDIAN)
        val bytesPerSample = if (encoding == AudioFormat.ENCODING_PCM_FLOAT) 4 else 2
        val frames = buffer.remaining() / (bytesPerSample * channels)
        val result = FloatArray(frames)
        for (i in 0 until frames) {
            var sum = 0f
            for (c in 0 until channels) {
                sum += if (encoding == AudioFormat.ENCODING_PCM_FLOAT) buffer.float
                    else (buffer.short.toInt() / 32768f)
            }
            result[i] = (sum / channels).coerceIn(-1f, 1f)
        }
        return result
    }

    private fun findHighlights() {
        if (transcript.isEmpty()) return
        highlights = HighlightRanker.rank(transcript)
        selectedHighlight = 0
        highlightList.removeAllViews()
        if (highlights.isEmpty()) {
            highlightList.addView(feature("No highlight windows found", "Try a different language selection or a longer video.")); return
        }
        highlights.forEachIndexed { index, h ->
            val b = Button(this).apply {
                isAllCaps = false; textSize = 12f; gravity = Gravity.START
                text = "${index + 1}. ${time(h.start)}–${time(h.end)}  •  ${"%.1f".format(h.score)}/10\n${h.preview}"
                setTextColor(Color.WHITE); setBackgroundColor(if (index == 0) Color.rgb(69, 52, 125) else Color.rgb(25, 29, 43))
                setOnClickListener {
                    selectedHighlight = index
                    startInput.setText("%.2f".format(Locale.US, h.start))
                    endInput.setText("%.2f".format(Locale.US, h.end))
                    status.text = "Selected highlight ${index + 1}. Review it in the player, then export."
                    video.seekTo((h.start * 1000).toInt()); video.start()
                    highlightList.childrenButtons(index)
                }
            }
            highlightList.addView(b, matchWrap().apply { bottomMargin = dp(6) })
        }
        val best = highlights.first()
        startInput.setText("%.2f".format(Locale.US, best.start))
        endInput.setText("%.2f".format(Locale.US, best.end))
        exportButton.isEnabled = true; exportButton.alpha = 1f
        status.text = "Found ${highlights.size} candidate moments. Highest-ranked is selected. Scores are heuristic—review before posting."
    }

    private fun LinearLayout.childrenButtons(selected: Int) {
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child is Button) child.setBackgroundColor(if (i == selected) Color.rgb(69, 52, 125) else Color.rgb(25, 29, 43))
        }
    }

    private fun exportClip() {
        val input = sourceFile ?: return
        val start = startInput.text.toString().toDoubleOrNull()
        val end = endInput.text.toString().toDoubleOrNull()
        if (start == null || end == null || start < 0 || end <= start) {
            status.text = "Enter valid start and end times."; return
        }
        exportButton.isEnabled = false
        status.text = "Exporting local MP4 and SRT captions…"
        thread {
            try {
                val outDir = File(getExternalFilesDir(null), "SNAP exports").apply { mkdirs() }
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val output = File(outDir, "SNAP_$stamp.mp4")
                trimWithMediaMuxer(input, output, start, end)
                val matching = transcript.filter { it.end > start && it.start < end }.map {
                    SpeechSegment(max(0.0, it.start - start), min(end - start, it.end - start), it.text)
                }
                val srtFile = File(outDir, "SNAP_$stamp.srt")
                srtFile.writeText(toSrt(matching), Charsets.UTF_8)
                runOnUiThread {
                    status.text = "Export complete!\n${output.absolutePath}\nCaption file: ${srtFile.name}\n${formatBytes(output.length())}\nNote: SRT is separate; captions are not burned into the video in this build."
                    Toast.makeText(this, "MP4 + SRT exported", Toast.LENGTH_LONG).show()
                    exportButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Export failed: ${e.message}"; exportButton.isEnabled = true }
            }
        }
    }

    private fun trimWithMediaMuxer(input: File, output: File, startSec: Double, endSec: Double) {
        val extractor = MediaExtractor(); extractor.setDataSource(input.absolutePath)
        val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val map = HashMap<Int, Int>()
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                extractor.selectTrack(i); map[i] = muxer.addTrack(format)
            }
        }
        require(map.isNotEmpty()) { "No audio/video tracks found" }
        var started = false
        try {
            muxer.start(); started = true
            val buffer = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            val startUs = (startSec * 1_000_000).toLong()
            val endUs = (endSec * 1_000_000).toLong()
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val actualStartUs = extractor.sampleTime.coerceAtLeast(0L)
            while (true) {
                buffer.clear()
                val track = extractor.sampleTrackIndex
                if (track < 0) break
                val time = extractor.sampleTime
                if (time < 0 || time >= endUs) break
                val dst = map[track]
                if (dst != null) {
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    if (time >= actualStartUs) {
                        info.offset = 0; info.size = size; info.presentationTimeUs = time - actualStartUs
                        info.flags = extractor.sampleFlags
                        muxer.writeSampleData(dst, buffer, info)
                    }
                }
                if (!extractor.advance()) break
            }
        } finally {
            if (started) try { muxer.stop() } catch (_: Exception) {}
            muxer.release(); extractor.release()
        }
    }

    private fun toSrt(items: List<SpeechSegment>): String = items.mapIndexed { i, s ->
        "${i + 1}\n${srtTime(s.start)} --> ${srtTime(s.end)}\n${s.text}\n"
    }.joinToString("\n")

    private fun srtTime(sec: Double): String {
        val ms = (sec.coerceAtLeast(0.0) * 1000).toLong()
        return "%02d:%02d:%02d,%03d".format(ms / 3600000, (ms / 60000) % 60, (ms / 1000) % 60, ms % 1000)
    }

    private fun time(sec: Double) = "%02d:%02d".format((sec / 60).toInt(), sec.toInt() % 60)
    private fun section(s: String) = TextView(this).apply {
        text = s; textSize = 11f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.rgb(167, 139, 250)); setPadding(0, dp(20), 0, dp(8))
    }
    private fun feature(title: String, desc: String) = TextView(this).apply {
        text = "$title\n$desc"; textSize = 12f; setTextColor(Color.WHITE)
        setPadding(dp(12), dp(11), dp(12), dp(11)); setBackgroundColor(Color.rgb(23, 26, 39))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }
    }
    private fun edit(value: String) = EditText(this).apply {
        setText(value); textSize = 16f; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        setSingleLine(); setPadding(dp(12), dp(8), dp(12), dp(8))
        setBackgroundColor(Color.rgb(28, 32, 47))
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
    }
    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(102, 75, 190)); setOnClickListener { action() }
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun formatBytes(n: Long): String = if (n > 1024L * 1024) "%.1f MB".format(n / 1048576.0) else "$n bytes"
    private fun safeName(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifBlank { "video.mp4" }

    private data class SpeechSegment(val start: Double, val end: Double, val text: String)
    private data class Highlight(val start: Double, val end: Double, val score: Double, val preview: String)

    private class FloatCollector {
        private var data = FloatArray(1 shl 18); private var size = 0
        fun add(v: Float) { if (size == data.size) data = data.copyOf(data.size * 2); data[size++] = v }
        fun toArray() = data.copyOf(size)
    }

    private object HighlightRanker {
        private val cues = listOf(
            "लेकिन", "मगर", "अचानक", "तभी", "रात", "अंधेरा", "खून", "चीख", "आवाज", "आवाज़",
            "दरवाजा", "दरवाज़ा", "परछाई", "परछाईं", "भूत", "प्रेत", "आत्मा", "डर", "डरावना",
            "रहस्य", "सच", "कभी", "क्यों", "कैसे", "कौन", "मत", "भाग", "मौत", "मर", "गायब",
            "चौंक", "विश्वास", "खतरा", "सन्नाटा", "कदम", "पीछे", "देखा", "सुना", "बाबा",
            "सरपंच", "गांव", "गाँव", "कहानी", "सोच", "नाम", "आखिर"
        )
        fun rank(segments: List<SpeechSegment>): List<Highlight> {
            if (segments.isEmpty()) return emptyList()
            val duration = segments.last().end
            val candidates = mutableListOf<Highlight>()
            var start = 0.0
            while (start < duration) {
                val end = min(start + 38.0, duration)
                if (end - start >= 15.0) {
                    val selected = segments.filter { it.end > start && it.start < end }
                    val text = selected.joinToString(" ") { it.text }
                    val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
                    val lower = text.lowercase()
                    val cueHits = cues.count { lower.contains(it) }
                    val question = if (text.contains("?") || text.contains("क्यों") || text.contains("कैसे")) 1 else 0
                    val dialogue = if (text.contains("बोले") || text.contains("कहा") || text.contains("पूछा")) 1 else 0
                    val punctuation = Regex("[!?।]").findAll(text).count().coerceAtMost(4)
                    val density = (words.size / max(1.0, end - start)).coerceIn(0.0, 4.0)
                    val score = (2.0 + cueHits * 0.55 + question * 0.8 + dialogue * 0.5 +
                        punctuation * 0.25 + density * 0.35).coerceIn(0.0, 10.0)
                    val preview = text.replace(Regex("\\s+"), " ").take(105).ifBlank { "Speech segment" }
                    candidates.add(Highlight(start, end, score, preview))
                }
                start += 12.0
            }
            return candidates.sortedByDescending { it.score }.distinctBy { (it.start / 8).toInt() }.take(8)
        }
    }
}

object WhisperNative {
    init { System.loadLibrary("whisper-jni") }
    external fun transcribe(audio16kMono: FloatArray, modelPath: String, language: String): String
}
