#include <jni.h>
#include <string>
#include <sstream>
#include <vector>
#include <android/log.h>
#include "whisper.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "SNAP-Whisper", __VA_ARGS__)

extern "C" JNIEXPORT jstring JNICALL
Java_com_snap_clipper_WhisperNative_transcribe(JNIEnv *env, jobject,
                                                jfloatArray audioArray,
                                                jstring modelPath,
                                                jstring language) {
    const char *model = env->GetStringUTFChars(modelPath, nullptr);
    const char *lang = env->GetStringUTFChars(language, nullptr);
    jsize n = env->GetArrayLength(audioArray);
    std::vector<float> audio((size_t)n);
    env->GetFloatArrayRegion(audioArray, 0, n, audio.data());

    whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    whisper_context *ctx = whisper_init_from_file_with_params(model, cparams);
    env->ReleaseStringUTFChars(modelPath, model);
    if (!ctx) {
        env->ReleaseStringUTFChars(language, lang);
        return env->NewStringUTF("ERROR|0|Unable to load Whisper model");
    }

    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.print_realtime = false;
    params.print_progress = false;
    params.print_timestamps = false;
    params.print_special = false;
    params.translate = false;
    params.no_context = true;
    params.single_segment = false;
    params.n_threads = 4;
    params.language = (std::string(lang) == "auto") ? nullptr : lang;
    params.detect_language = (std::string(lang) == "auto");
    params.token_timestamps = false;
    params.suppress_blank = true;
    params.suppress_nst = true;

    int result = whisper_full(ctx, params, audio.data(), (int)audio.size());
    env->ReleaseStringUTFChars(language, lang);
    if (result != 0) {
        whisper_free(ctx);
        return env->NewStringUTF("ERROR|0|Whisper inference failed");
    }

    std::ostringstream out;
    const int count = whisper_full_n_segments(ctx);
    for (int i = 0; i < count; ++i) {
        int64_t t0 = whisper_full_get_segment_t0(ctx, i) * 10;
        int64_t t1 = whisper_full_get_segment_t1(ctx, i) * 10;
        const char *txt = whisper_full_get_segment_text(ctx, i);
        if (!txt) continue;
        std::string clean(txt);
        for (char &c : clean) if (c == '|' || c == '\n' || c == '\r') c = ' ';
        if (clean.find_first_not_of(" \t") == std::string::npos) continue;
        out << t0 << "|" << t1 << "|" << clean << "\n";
    }
    whisper_free(ctx);
    return env->NewStringUTF(out.str().c_str());
}
