#include <jni.h>
extern "C" JNIEXPORT jstring JNICALL
Java_com_snap_clipper_WhisperNative_transcribe(JNIEnv *env, jobject, jfloatArray, jstring, jstring) {
    return env->NewStringUTF("ERROR|0|Whisper native engine was not included in this build.");
}
