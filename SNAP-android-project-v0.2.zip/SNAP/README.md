# SNAP — Offline Android video clipping app (0.2)

SNAP is a native Kotlin Android application intended for Android 8+ and ARM64 tablets. It does not require Termux, Python, a paid API, or a cloud processing account.

## Implemented in this build
- Native Android app and document-picker video import.
- Local video preview.
- One-time download of the Whisper.cpp `ggml-base` model (~142 MB).
- Native Whisper.cpp JNI engine, compiled for Android ARM64 by GitHub Actions.
- On-device audio decoding with Android MediaCodec, mono downmix and 16 kHz resampling.
- Hindi / English / auto language selection.
- On-device speech transcription with segment timestamps.
- SRT subtitle sidecar generation.
- Hindi-oriented heuristic highlight ranking (up to 8 candidate windows).
- Select a candidate and export the matching MP4 clip locally.
- Matching SRT captions are exported next to the MP4.

## Not yet implemented (do not treat as available)
- 9:16 portrait crop/reframing and face tracking.
- Burned-in animated captions, word-by-word karaoke highlighting.
- Caption font/theme controls, brand templates, transitions and sound-effect timeline.
- Reliable semantic AI understanding of Hindi story twists. Current highlight ranking is a transparent keyword/structure heuristic and must be reviewed.
- Background transcription notification / resumable model download.
- Play Store release signing.

The MP4 export currently uses Android MediaExtractor/MediaMuxer stream-copy. It preserves the source frame dimensions and codec; the SRT file is separate and is not burned into the video.

## Build without Termux
1. Create a GitHub repository named `SNAP`.
2. Upload the contents of this folder to the repository root.
3. Open **Actions → Build SNAP APK** and run the workflow (or push to `main`).
4. Download the `SNAP-debug-apk` artifact, extract `app-debug.apk`, and install it on the tablet.
5. Open SNAP, import a video, tap **Download Whisper model** once, then choose Hindi and tap **Transcribe video**. Subsequent transcription can run offline.

The workflow clones the upstream Whisper.cpp source at build time and compiles it into the APK. The model is downloaded separately on first launch.

## Device notes
- This build targets `arm64-v8a`, suitable for the Realme Pad 2.
- Long videos can take several minutes and require substantial free RAM/storage. Close other apps during long transcriptions.
- The app stores its model and working files in private app storage. Uninstalling SNAP removes these files.
- Model download requires internet. Transcription, ranking and clip export run locally.
- The Whisper model and Whisper.cpp are third-party open-source components; see their upstream licenses.
